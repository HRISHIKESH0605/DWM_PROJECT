import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

st.set_page_config(page_title="Movie Dashboard", layout="wide")
st.title("🎬 Movie Trends Dashboard + Recommendation System")

# =========================
# LOAD DATA
# =========================
@st.cache_data
def load_data():

    def read(file):
        try:
            return pd.read_csv(file, encoding='latin1', on_bad_lines='skip', engine='python')
        except:
            return pd.DataFrame()

    def process(df, industry):
        if df.empty:
            return pd.DataFrame()

        cols = df.columns

        def find(names):
            for name in names:
                match = cols[cols.str.contains(name, case=False)]
                if len(match) > 0:
                    return match[0]
            return None

        new = pd.DataFrame()

        new['title'] = df[find(['title','movie','name'])] if find(['title','movie','name']) else "Unknown"
        new['budget'] = df[find(['budget'])] if find(['budget']) else 0
        new['revenue'] = df[find(['revenue','gross'])] if find(['revenue','gross']) else 0
        new['popularity'] = df[find(['popularity','rating'])] if find(['popularity','rating']) else 0
        new['release_date'] = df[find(['date','year'])] if find(['date','year']) else None
        new['genres'] = df[find(['genre'])] if find(['genre']) else "Unknown"
        new['language'] = df[find(['language','original'])] if find(['language','original']) else "Unknown"

        new['industry'] = industry
        return new

    hollywood = process(read("hollywood.csv"), "Hollywood")
    indian = process(read("indian.csv"), "Indian")

    telugu_raw = read("telugu.csv")
    if not telugu_raw.empty:
        telugu = telugu_raw.copy()
        required = ['title','budget','revenue','popularity','release_date','genres','language']
        for col in required:
            if col not in telugu.columns:
                telugu[col] = 0
        telugu['industry'] = "Telugu"
    else:
        telugu = pd.DataFrame()

    df = pd.concat([hollywood, indian, telugu], ignore_index=True)

    df = df.fillna(0)

    df['year'] = pd.to_datetime(df['release_date'], errors='coerce').dt.year.fillna(0)
    df = df[df['year'] >= 2000]

    df['budget'] = pd.to_numeric(df['budget'], errors='coerce').fillna(0)
    df['revenue'] = pd.to_numeric(df['revenue'], errors='coerce').fillna(0)
    df['popularity'] = pd.to_numeric(df['popularity'], errors='coerce').fillna(0)

    df['success'] = (df['revenue'] > df['budget']).astype(int)

    return df


df = load_data()

if df.empty:
    st.error("❌ No data loaded")
    st.stop()

# =========================
# FILTERS
# =========================
st.sidebar.header("Filters")

industry_filter = st.sidebar.multiselect(
    "Industry",
    df['industry'].unique(),
    default=df['industry'].unique()
)

df_filtered = df[df['industry'].isin(industry_filter)]

# =========================
# VISUALS
# =========================
st.subheader("📊 Movie Trends Analysis")

col1, col2 = st.columns(2)

with col1:
    fig1 = px.line(
        df_filtered['year'].value_counts().sort_index(),
        markers=True,
        title="📅 Movies Released Per Year"
    )
    fig1.update_layout(template="plotly_dark")
    st.plotly_chart(fig1, use_container_width=True)

with col2:
    fig2 = px.scatter(
        df_filtered,
        x='budget',
        y='revenue',
        color='industry',
        size='popularity',
        hover_data=['title'],
        title="💰 Budget vs Revenue"
    )
    fig2.update_layout(template="plotly_dark")
    st.plotly_chart(fig2, use_container_width=True)

st.subheader("🏭 Industry Revenue Comparison")
fig3 = px.box(df_filtered, x='industry', y='revenue', color='industry', title="Revenue Distribution")
fig3.update_layout(template="plotly_dark")
st.plotly_chart(fig3, use_container_width=True)

# =========================
# 🎬 MOVIE EXPLORER
# =========================
st.subheader("🎬 Movie Explorer")

search = st.text_input("🔍 Search Movie")

movie_df = df_filtered.copy()
movie_df['display'] = movie_df['title'].astype(str) + " (" + movie_df['industry'] + ")"

if search:
    movie_df = movie_df[movie_df['title'].str.contains(search, case=False, na=False)]

movie_list = movie_df['display'].unique()

selected = st.selectbox("Select Movie", movie_list)

selected_row = movie_df[movie_df['display'] == selected]

if not selected_row.empty:
    m = selected_row.iloc[0]

    st.markdown("### 📄 Movie Details")

    col1, col2 = st.columns(2)

    col1.write(f"🎬 Title: {m['title']}")
    col1.write(f"🏭 Industry: {m['industry']}")
    col1.write(f"🎭 Genre: {m['genres']}")

    col2.write(f"💵 Revenue: {int(m['revenue'])}")
    col2.write(f"⭐ Popularity: {m['popularity']}")
    col2.write(f"📅 Year: {int(m['year'])}")

# =========================
# 🎯 RECOMMENDATION SYSTEM (GENRE + LANGUAGE)
# =========================
st.subheader("🎯 Movie Recommendation System")

selected_genre = st.selectbox("Select Genre", df['genres'].astype(str).unique())
selected_language = st.selectbox("Select Language", df['language'].astype(str).unique())

recommended = df[
    (df['genres'].astype(str) == selected_genre) &
    (df['language'].astype(str) == selected_language)
]

st.write("🎬 Recommended Movies:")

if not recommended.empty:
    for _, row in recommended.head(10).iterrows():
        st.write(f"👉 {row['title']} ({row['industry']})")
else:
    st.warning("No movies found for selected genre & language")

# =========================
# ML
# =========================
st.subheader("🤖 Movie Success Prediction")

X = df_filtered[['budget', 'popularity']]
y = df_filtered['success']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

model = RandomForestClassifier()
model.fit(X_train, y_train)

budget = st.number_input("Enter Budget", value=50000000)
popularity = st.number_input("Enter Popularity", value=10.0)

if st.button("Predict"):
    result = model.predict([[budget, popularity]])
    st.success("🎉 HIT Movie" if result[0] == 1 else "❌ FLOP Movie")

st.write("📊 Accuracy:", model.score(X_test, y_test))